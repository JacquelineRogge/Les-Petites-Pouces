﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProjetFinal_KaoutarLakhal.Models;

namespace ProjetFinal_KaoutarLakhal.Areas.Identity.Pages.Account.Manage
{
    public partial class IndexModel : PageModel
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly SignInManager<AppUser> _signInManager;

        public IndexModel(
            UserManager<AppUser> userManager,
            SignInManager<AppUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        public string Username { get; set; }

        [TempData]
        public string StatusMessage { get; set; }

        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel
        {
            [Phone]
            [Display(Name = "Phone number")]
            public string PhoneNumber { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "Nom")]
            public string Nom { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "Prénom")]
            public string Prenom { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "No. civique et rue")]
            public string NumCivique_Rue { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "No. Appartement")]
            public string Appartement { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "Ville")]
            public string Ville { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "Province")]
            public string Province { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "Pays")]
            public string Pays { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "Code Postal")]
            public string CP { get; set; }

            [DataType(DataType.Text)]
            [Display(Name = "Num. télephone")]
            public string Telephone { get; set; }

            [Required]
            [DataType(DataType.Text)]
            [Display(Name = "Num. cellulaire")]
            public string cellulaire { get; set; }

        }

        private async Task LoadAsync(AppUser user)
        {
            var userName = await _userManager.GetUserNameAsync(user);
            var phoneNumber = await _userManager.GetPhoneNumberAsync(user);

            Username = userName;

            Input = new InputModel
            {
                PhoneNumber = phoneNumber,
                Nom = user.Nom,
                Prenom = user.Prenom,
                NumCivique_Rue = user.NumCivique_Rue,
                Appartement = user.Appartement,
                Ville = user.Ville,
                Province = user.Province,
                Pays = user.Pays,
                CP = user.CP,
                Telephone = user.Telephone,
                cellulaire = user.cellulaire
            };
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            await LoadAsync(user);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound($"Unable to load user with ID '{_userManager.GetUserId(User)}'.");
            }

            if (!ModelState.IsValid)
            {
                await LoadAsync(user);
                return Page();
            }

            var phoneNumber = await _userManager.GetPhoneNumberAsync(user);
            if (Input.PhoneNumber != phoneNumber)
            {
                var setPhoneResult = await _userManager.SetPhoneNumberAsync(user, Input.PhoneNumber);
                if (!setPhoneResult.Succeeded)
                {
                    StatusMessage = "Unexpected error when trying to set phone number.";
                    return RedirectToPage();
                }
            }

            if (Input.Nom != user.Nom)
            {
                user.Nom = Input.Nom;
            }

            if (Input.Prenom != user.Prenom)
            {
                user.Prenom = Input.Prenom;
            }

            if (Input.NumCivique_Rue != user.NumCivique_Rue)
            {
                user.NumCivique_Rue = Input.NumCivique_Rue;
            }

            if (Input.Appartement != user.Appartement)
            {
                user.Appartement = Input.Appartement;
            }

            if (Input.Ville != user.Ville)
            {
                user.Ville = Input.Ville;
            }

            if (Input.Province != user.Province)
            {
                user.Province = Input.Province;
            }

            if (Input.Pays != user.Pays)
            {
                user.Pays = Input.Pays;
            }

            if (Input.CP != user.CP)
            {
                user.CP = Input.CP;
            }

            if (Input.Telephone != user.Telephone)
            {
                user.Telephone = Input.Telephone;
            }

            if (Input.cellulaire != user.cellulaire)
            {
                user.cellulaire = Input.cellulaire;
            }

            await _userManager.UpdateAsync(user);
            await _signInManager.RefreshSignInAsync(user);
            StatusMessage = "Votre profil a été mis a jour";
            return RedirectToPage();
        }
    }
}
