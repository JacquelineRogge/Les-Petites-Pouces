﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjetFinal_KaoutarLakhal.Models;

namespace ProjetFinal_KaoutarLakhal.Controllers
{
    public class LignePanierController : Controller
    {
        private readonly IdentityAppContext _context;

        public LignePanierController(IdentityAppContext context)
        {
            _context = context;
        }

        // GET: LignePanier
        public async Task<IActionResult> Index()
        {

            var userId = Int32.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            //if (userId != null)
            //{
                var identityAppContext = _context.LignePanier.Include(l => l.Livre).Include(l => l.Panier).Where(l => l.PanierId == userId);
                return View(await identityAppContext.ToListAsync());

            //}
            
        }


        // GET: LignePanier/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lignePanier = await _context.LignePanier
                .Include(l => l.Livre)
                .Include(l => l.Panier)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (lignePanier == null)
            {
                return NotFound();
            }

            return View(lignePanier);
        }

        // GET: LignePanier/Create
        public async Task<IActionResult> Create(int? id)
        {
            var userId = Int32.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var estExist = await _context.Panier.FindAsync(userId);
            if (estExist == null)
            {

                _context.Panier.Add(new Panier() {  UserId = userId });
                await _context.SaveChangesAsync();
            }

            var livre = await _context.Livre.FindAsync(id);
            _context.LignePanier.Add(new LignePanier() { LivreId=livre.Id,PanierId= userId, QuantiteAjoute=1, Maontant=livre.PrixUnitaire });
            await _context.SaveChangesAsync();
            //ViewData["LivreId"] = new SelectList(_context.Livre, "Id", "Auteur");
            //ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id");
            //return View();
            return RedirectToAction(nameof(Index));
        }

        // POST: LignePanier/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreatePost([Bind("Id,LivreId,PanierId,QuantiteAjoute,Maontant")] LignePanier lignePanier)
        {
            
            if (ModelState.IsValid)
            {
                _context.Add(lignePanier);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["LivreId"] = new SelectList(_context.Livre, "Id", "Auteur", lignePanier.LivreId);
            ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id", lignePanier.PanierId);
            return View(lignePanier);
        }

        // GET: LignePanier/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lignePanier = await _context.LignePanier.FindAsync(id);
            if (lignePanier == null)
            {
                return NotFound();
            }
            ViewData["LivreId"] = new SelectList(_context.Livre, "Id", "Auteur", lignePanier.LivreId);
            ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id", lignePanier.PanierId);
            return View(lignePanier);
        }

        // POST: LignePanier/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,LivreId,PanierId,QuantiteAjoute,Maontant")] LignePanier lignePanier)
        {
            if (id != lignePanier.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var livre = await _context.Livre.FindAsync(lignePanier.LivreId);
                    var prixLivre = livre.PrixUnitaire;

                    var newMontant = prixLivre * lignePanier.QuantiteAjoute;

                    lignePanier.Maontant = newMontant;

                    _context.Update(lignePanier);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!LignePanierExists(lignePanier.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["LivreId"] = new SelectList(_context.Livre, "Id", "Auteur", lignePanier.LivreId);
            ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id", lignePanier.PanierId);
            return View(lignePanier);
        }

        // GET: LignePanier/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var lignePanier = await _context.LignePanier
                .Include(l => l.Livre)
                .Include(l => l.Panier)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (lignePanier == null)
            {
                return NotFound();
            }

            return View(lignePanier);
        }

        // POST: LignePanier/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var lignePanier = await _context.LignePanier.FindAsync(id);
            _context.LignePanier.Remove(lignePanier);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool LignePanierExists(int id)
        {
            return _context.LignePanier.Any(e => e.Id == id);
        }
    }
}
