﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjetFinal_KaoutarLakhal.Models;

namespace ProjetFinal_KaoutarLakhal.Controllers
{
    public class CommandeController : Controller
    {
        private readonly IdentityAppContext _context;

        public CommandeController(IdentityAppContext context)
        {
            _context = context;
        }

        // GET: Commande
        public async Task<IActionResult> Index()
        {
            var identityAppContext = _context.Commande.Include(c => c.Panier).Include(c => c.StatutCommande).Include(c => c.TypeLivraison);
            return View(await identityAppContext.ToListAsync());
        }

        // GET: Commande/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var commande = await _context.Commande
                .Include(c => c.Panier)
                .Include(c => c.StatutCommande)
                .Include(c => c.TypeLivraison)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (commande == null)
            {
                return NotFound();
            }

            return View(commande);
        }

        // GET: Commande/Create
        public async  Task<IActionResult> Create(int? id )
        {

            _context.Commande.Add(new Commande() {  DateCommande = DateTime.Now ,StatutCommandeId = 1, TotalAvTaxe=54.00, TotalApTaxe=62.09 , PanierId = 11 , TypeLivraisonId=1});
            //_context.Commande.Add(new Commande() {  DateCommande = DateTime.Now ,StatutCommandeId = 1 , PanierId = 10 , TypeLivraisonId=1});
            await _context.SaveChangesAsync();

            


            //ViewData["LivreId"] = new SelectList(_context.Livre, "Id", "Auteur");
            //ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id");
            //return View();
            return RedirectToAction(nameof(Index));
            //ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id");
            //ViewData["StatutCommandeId"] = new SelectList(_context.StatutCommande, "Id", "StatutDescription");
            //ViewData["TypeLivraisonId"] = new SelectList(_context.TypeLivraison, "Id", "TypeDescription");
            //return View();
        }

        // POST: Commande/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,DateCommande,TotalAvTaxe,TotalApTaxe,PanierId,StatutCommandeId,TypeLivraisonId")] Commande commande)
        {
            if (ModelState.IsValid)
            {
                _context.Add(commande);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id", commande.PanierId);
            ViewData["StatutCommandeId"] = new SelectList(_context.StatutCommande, "Id", "StatutDescription", commande.StatutCommandeId);
            ViewData["TypeLivraisonId"] = new SelectList(_context.TypeLivraison, "Id", "TypeDescription", commande.TypeLivraisonId);
            return View(commande);
        }

        // GET: Commande/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var commande = await _context.Commande.FindAsync(id);
            if (commande == null)
            {
                return NotFound();
            }
            ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id", commande.PanierId);
            ViewData["StatutCommandeId"] = new SelectList(_context.StatutCommande, "Id", "StatutDescription", commande.StatutCommandeId);
            ViewData["TypeLivraisonId"] = new SelectList(_context.TypeLivraison, "Id", "TypeDescription", commande.TypeLivraisonId);
            return View(commande);
        }

        // POST: Commande/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,DateCommande,TotalAvTaxe,TotalApTaxe,PanierId,StatutCommandeId,TypeLivraisonId")] Commande commande)
        {
            if (id != commande.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(commande);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CommandeExists(commande.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PanierId"] = new SelectList(_context.Panier, "Id", "Id", commande.PanierId);
            ViewData["StatutCommandeId"] = new SelectList(_context.StatutCommande, "Id", "StatutDescription", commande.StatutCommandeId);
            ViewData["TypeLivraisonId"] = new SelectList(_context.TypeLivraison, "Id", "TypeDescription", commande.TypeLivraisonId);
            return View(commande);
        }

        // GET: Commande/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var commande = await _context.Commande
                .Include(c => c.Panier)
                .Include(c => c.StatutCommande)
                .Include(c => c.TypeLivraison)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (commande == null)
            {
                return NotFound();
            }

            return View(commande);
        }

        // POST: Commande/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var commande = await _context.Commande.FindAsync(id);
            _context.Commande.Remove(commande);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CommandeExists(int id)
        {
            return _context.Commande.Any(e => e.Id == id);
        }
    }
}
