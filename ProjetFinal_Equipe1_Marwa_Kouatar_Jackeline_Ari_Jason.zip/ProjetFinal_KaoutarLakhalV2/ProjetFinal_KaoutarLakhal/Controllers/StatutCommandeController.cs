﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjetFinal_KaoutarLakhal.Models;

namespace ProjetFinal_KaoutarLakhal.Controllers
{
    public class StatutCommandeController : Controller
    {
        private readonly IdentityAppContext _context;

        public StatutCommandeController(IdentityAppContext context)
        {
            _context = context;
        }

        // GET: StatutCommande
        public async Task<IActionResult> Index()
        {
            return View(await _context.StatutCommande.ToListAsync());
        }

        // GET: StatutCommande/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var statutCommande = await _context.StatutCommande
                .FirstOrDefaultAsync(m => m.Id == id);
            if (statutCommande == null)
            {
                return NotFound();
            }

            return View(statutCommande);
        }

        // GET: StatutCommande/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: StatutCommande/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,StatutDescription")] StatutCommande statutCommande)
        {
            if (ModelState.IsValid)
            {
                _context.Add(statutCommande);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(statutCommande);
        }

        // GET: StatutCommande/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var statutCommande = await _context.StatutCommande.FindAsync(id);
            if (statutCommande == null)
            {
                return NotFound();
            }
            return View(statutCommande);
        }

        // POST: StatutCommande/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,StatutDescription")] StatutCommande statutCommande)
        {
            if (id != statutCommande.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(statutCommande);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StatutCommandeExists(statutCommande.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(statutCommande);
        }

        // GET: StatutCommande/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var statutCommande = await _context.StatutCommande
                .FirstOrDefaultAsync(m => m.Id == id);
            if (statutCommande == null)
            {
                return NotFound();
            }

            return View(statutCommande);
        }

        // POST: StatutCommande/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var statutCommande = await _context.StatutCommande.FindAsync(id);
            _context.StatutCommande.Remove(statutCommande);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StatutCommandeExists(int id)
        {
            return _context.StatutCommande.Any(e => e.Id == id);
        }
    }
}
