﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ProjetFinal_KaoutarLakhal.Models;

namespace ProjetFinal_KaoutarLakhal.Controllers
{
    public class TypeLivraisonController : Controller
    {
        private readonly IdentityAppContext _context;

        public TypeLivraisonController(IdentityAppContext context)
        {
            _context = context;
        }

        // GET: TypeLivraison
        public async Task<IActionResult> Index()
        {
            return View(await _context.TypeLivraison.ToListAsync());
        }

        // GET: TypeLivraison/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var typeLivraison = await _context.TypeLivraison
                .FirstOrDefaultAsync(m => m.Id == id);
            if (typeLivraison == null)
            {
                return NotFound();
            }

            return View(typeLivraison);
        }

        // GET: TypeLivraison/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TypeLivraison/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,TypeDescription,PrixLivraison")] TypeLivraison typeLivraison)
        {
            if (ModelState.IsValid)
            {
                _context.Add(typeLivraison);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(typeLivraison);
        }

        // GET: TypeLivraison/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var typeLivraison = await _context.TypeLivraison.FindAsync(id);
            if (typeLivraison == null)
            {
                return NotFound();
            }
            return View(typeLivraison);
        }

        // POST: TypeLivraison/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,TypeDescription,PrixLivraison")] TypeLivraison typeLivraison)
        {
            if (id != typeLivraison.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(typeLivraison);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TypeLivraisonExists(typeLivraison.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(typeLivraison);
        }

        // GET: TypeLivraison/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var typeLivraison = await _context.TypeLivraison
                .FirstOrDefaultAsync(m => m.Id == id);
            if (typeLivraison == null)
            {
                return NotFound();
            }

            return View(typeLivraison);
        }

        // POST: TypeLivraison/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var typeLivraison = await _context.TypeLivraison.FindAsync(id);
            _context.TypeLivraison.Remove(typeLivraison);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TypeLivraisonExists(int id)
        {
            return _context.TypeLivraison.Any(e => e.Id == id);
        }
    }
}
