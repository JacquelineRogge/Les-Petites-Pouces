﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace ProjetFinal_KaoutarLakhal.Models
{
    public partial class Livre
    {
        public Livre()
        {
            LignePanier = new HashSet<LignePanier>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Required]
        [StringLength(100)]
        public string Titre { get; set; }
        
        [StringLength(150)]
        public string Image { get; set; }
        public double PrixUnitaire { get; set; }
        public int Quantite { get; set; }
        [Column(TypeName = "decimal(18, 0)")]
        public decimal Poind { get; set; }
        [Required]
        [StringLength(300)]
        public string Description { get; set; }
        [Required]
        [StringLength(100)]
        public string Auteur { get; set; }
        [Column(TypeName = "date")]
        public DateTime DateParution { get; set; }
        public bool Disponibilite { get; set; }
        [Column("CategorieID")]
        public int CategorieId { get; set; }

        [ForeignKey(nameof(CategorieId))]
        [InverseProperty("Livre")]
        public virtual Categorie Categorie { get; set; }
        [InverseProperty("Livre")]
        public virtual ICollection<LignePanier> LignePanier { get; set; }
    }
}
