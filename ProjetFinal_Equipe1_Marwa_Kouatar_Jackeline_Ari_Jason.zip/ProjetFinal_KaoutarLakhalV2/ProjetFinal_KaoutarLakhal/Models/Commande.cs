﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace ProjetFinal_KaoutarLakhal.Models
{
    public partial class Commande
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime DateCommande { get; set; }
        public double TotalAvTaxe { get; set; }
        public double TotalApTaxe { get; set; }
        [Column("PanierID")]
        public int PanierId { get; set; }
        [Column("StatutCommandeID")]
        public int StatutCommandeId { get; set; }
        [Column("TypeLivraisonID")]
        public int TypeLivraisonId { get; set; }

        [ForeignKey(nameof(PanierId))]
        [InverseProperty("Commande")]
        public virtual Panier Panier { get; set; }
        [ForeignKey(nameof(StatutCommandeId))]
        [InverseProperty("Commande")]
        public virtual StatutCommande StatutCommande { get; set; }
        [ForeignKey(nameof(TypeLivraisonId))]
        [InverseProperty("Commande")]
        public virtual TypeLivraison TypeLivraison { get; set; }
    }
}
