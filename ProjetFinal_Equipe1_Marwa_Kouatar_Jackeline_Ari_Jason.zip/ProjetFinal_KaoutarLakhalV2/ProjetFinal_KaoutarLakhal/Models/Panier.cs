﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace ProjetFinal_KaoutarLakhal.Models
{
    public partial class Panier
    {
        public Panier()
        {
            //Commande = new HashSet<Commande>();
            LignePanier = new HashSet<LignePanier>();
        }

        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column("UserID")]
        public int UserId { get; set; }

        //[ForeignKey(nameof(UserId))]
        //[InverseProperty(nameof(AspNetUsers.Panier))]
        //public virtual AspNetUsers User { get; set; }
        //[InverseProperty("Panier")]
        //[ForeignKey(nameof(UserId))]
        //[InverseProperty("Panier")]
        //public virtual AppUser User { get; set; }
        //[InverseProperty("Panier")]

        public virtual Commande Commande { get; set; }
        [InverseProperty("Panier")]
        public virtual ICollection<LignePanier> LignePanier { get; set; }
    }
}
