﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetFinal_KaoutarLakhal.Models
{
    public class AppUser: IdentityUser<int>
    {
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string NumCivique_Rue { get; set; }
        public string Appartement { get; set; }
        public string Ville { get; set; }
        public string Province { get; set; }
        public string Pays { get; set; }
        public string CP { get; set; }
        public string Telephone { get; set; }
        public string cellulaire { get; set; }




    }
}
