﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjetFinal_KaoutarLakhal.Models
{
    public class IdentityAppContext: IdentityDbContext<AppUser, AppRole, int>
    {
        public IdentityAppContext(DbContextOptions<IdentityAppContext> options) : base(options)
        {

        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) 
        {
            //optionsBuilder.UseSqlServer("Server =(localdb)\\mssqllocaldb;Database=DBProjetFinalEquipe1;Trusted_Connection=True;"); 
            //optionsBuilder.UseSqlServer("Server=tcp:424sql.cgodin.qc.ca,5433;Database=BDWPojetFinalEquipe1;User Id=E22equipe1;Password=Secret16113");

        }
        public virtual DbSet<Categorie> Categorie { get; set; }
        public virtual DbSet<Commande> Commande { get; set; }
        public virtual DbSet<LignePanier> LignePanier { get; set; }
        public virtual DbSet<Livre> Livre { get; set; }
        public virtual DbSet<Panier> Panier { get; set; }
        public virtual DbSet<StatutCommande> StatutCommande { get; set; }
        public virtual DbSet<TypeLivraison> TypeLivraison { get; set; }
        public virtual DbSet<AppUser> Users { get; set; }


    }
}
