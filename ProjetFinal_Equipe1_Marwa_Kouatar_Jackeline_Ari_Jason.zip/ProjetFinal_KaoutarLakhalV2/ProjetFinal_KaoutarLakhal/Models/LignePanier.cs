﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace ProjetFinal_KaoutarLakhal.Models
{
    public partial class LignePanier
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column("LivreID")]
        public int LivreId { get; set; }
        [Column("PanierID")]
        public int PanierId { get; set; }
        public int QuantiteAjoute { get; set; }
        public double Maontant { get; set; }

        [ForeignKey(nameof(LivreId))]
        [InverseProperty("LignePanier")]
        public virtual Livre Livre { get; set; }
        [ForeignKey(nameof(PanierId))]
        [InverseProperty("LignePanier")]
        public virtual Panier Panier { get; set; }
    }
}
