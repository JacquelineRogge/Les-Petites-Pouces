﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ProjetFinal_KaoutarLakhal.Migrations
{
    public partial class Initialcreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categorie",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(maxLength: 50, nullable: false),
                    img = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categorie", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Panier",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Panier", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "StatutCommande",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StatutDescription = table.Column<string>(maxLength: 35, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StatutCommande", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "TypeLivraison",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TypeDescription = table.Column<string>(maxLength: 35, nullable: false),
                    PrixLivraison = table.Column<double>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TypeLivraison", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Livre",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Titre = table.Column<string>(maxLength: 100, nullable: false),
                    Image = table.Column<string>(maxLength: 150, nullable: false),
                    PrixUnitaire = table.Column<double>(nullable: false),
                    Quantite = table.Column<int>(nullable: false),
                    Poind = table.Column<decimal>(type: "decimal(18, 0)", nullable: false),
                    Description = table.Column<string>(maxLength: 300, nullable: false),
                    Auteur = table.Column<string>(maxLength: 100, nullable: false),
                    DateParution = table.Column<DateTime>(type: "date", nullable: false),
                    Disponibilite = table.Column<bool>(nullable: false),
                    CategorieID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Livre", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Livre_Categorie_CategorieID",
                        column: x => x.CategorieID,
                        principalTable: "Categorie",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Commande",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DateCommande = table.Column<DateTime>(type: "date", nullable: false),
                    TotalAvTaxe = table.Column<double>(nullable: false),
                    TotalApTaxe = table.Column<double>(nullable: false),
                    PanierID = table.Column<int>(nullable: false),
                    StatutCommandeID = table.Column<int>(nullable: false),
                    TypeLivraisonID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Commande", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Commande_Panier_PanierID",
                        column: x => x.PanierID,
                        principalTable: "Panier",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Commande_StatutCommande_StatutCommandeID",
                        column: x => x.StatutCommandeID,
                        principalTable: "StatutCommande",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Commande_TypeLivraison_TypeLivraisonID",
                        column: x => x.TypeLivraisonID,
                        principalTable: "TypeLivraison",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LignePanier",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LivreID = table.Column<int>(nullable: false),
                    PanierID = table.Column<int>(nullable: false),
                    QuantiteAjoute = table.Column<int>(nullable: false),
                    Maontant = table.Column<double>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LignePanier", x => x.ID);
                    table.ForeignKey(
                        name: "FK_LignePanier_Livre_LivreID",
                        column: x => x.LivreID,
                        principalTable: "Livre",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_LignePanier_Panier_PanierID",
                        column: x => x.PanierID,
                        principalTable: "Panier",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Commande_PanierID",
                table: "Commande",
                column: "PanierID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Commande_StatutCommandeID",
                table: "Commande",
                column: "StatutCommandeID");

            migrationBuilder.CreateIndex(
                name: "IX_Commande_TypeLivraisonID",
                table: "Commande",
                column: "TypeLivraisonID");

            migrationBuilder.CreateIndex(
                name: "IX_LignePanier_LivreID",
                table: "LignePanier",
                column: "LivreID");

            migrationBuilder.CreateIndex(
                name: "IX_LignePanier_PanierID",
                table: "LignePanier",
                column: "PanierID");

            migrationBuilder.CreateIndex(
                name: "IX_Livre_CategorieID",
                table: "Livre",
                column: "CategorieID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Commande");

            migrationBuilder.DropTable(
                name: "LignePanier");

            migrationBuilder.DropTable(
                name: "StatutCommande");

            migrationBuilder.DropTable(
                name: "TypeLivraison");

            migrationBuilder.DropTable(
                name: "Livre");

            migrationBuilder.DropTable(
                name: "Panier");

            migrationBuilder.DropTable(
                name: "Categorie");
        }
    }
}
